
Server api

npm install

configure Azure SQL database - config/default.json

npm run dev

client

see api-client folder