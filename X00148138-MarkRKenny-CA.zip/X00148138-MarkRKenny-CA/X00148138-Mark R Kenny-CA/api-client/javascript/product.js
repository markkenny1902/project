// JavaScript for the product page
function displayProducts(products) {
    const rows = products.map(product => {
  
        let row = `<tr>
                <td>${product.ProductId}</td>
                <td>${product.ProductName}</td>
                <td>${product.ProductDescription}</td>
                <td>${product.ProductStock}</td>
                <td class="price">&euro;${Number(product.ProductPrice).toFixed(2)}</td>`
      

        // shows the role for admin     
        if (userLoggedIn() === true  && sessionStorage.getItem('role') === ('admin')) {      
            row+= `<td><button class="btn btn-xs" data-toggle="modal" data-target="#ProductFormDialog" onclick="prepareProductUpdate(${product.ProductId})"><span class="oi oi-pencil"></span></button></td>
                   <td><button class="btn btn-xs" onclick="deleteProduct(${product.ProductId})"><span class="oi oi-trash"></span></button></td>`
        }
        // shows the role for a manager
        if (userLoggedIn() === true  && sessionStorage.getItem('role') === ('manager')) {      
          row+= `<td><button class="btn btn-xs" data-toggle="modal" data-target="#ProductFormDialog" onclick="prepareProductUpdate(${product.ProductId})"><span class="oi oi-pencil"></span></button></td>`
      }
        row+= '</tr>';

       return row;       
    });
  

    document.getElementById('productRows').innerHTML = rows.join('');
  } 
  
  
  // load and display brands 
  function displayCategories(brands) {
    //console.log(brands);
    const items = brands.map(brand => {
      return `<a href="#" class="list-group-item list-group-item-action" onclick="updateProductsView(${brand.BrandId})">${brand.BrandName}</a>`;
    });
  
    // Add an All brands link at the start
    items.unshift(`<a href="#" class="list-group-item list-group-item-action" onclick="loadProducts()">Show all</a>`);
  
    // Set the innerHTML of the productRows root element = rows
    document.getElementById('brandList').innerHTML = items.join('');
  } 
  
  
  // Get all brands and products then display
  async function loadProducts() {
    try {
      const brand = await getDataAsync(`${BASE_URL}brand`);
      displayCategories(brand);
  
      const products = await getDataAsync(`${BASE_URL}product`);
      displayProducts(products);
  
    } // catch and log any errors
    catch (err) {
      console.log(err);
    }
  }
  
  // update products list when brand is selected to show only products from that brand
  async function updateProductsView(id) {
    try {
      const products = await getDataAsync(`${BASE_URL}product/bybra/${id}`);
      displayProducts(products);
  
    } // catch and log any errors
    catch (err) {
      console.log(err);
    }
  }
  
  // When a product is selected for update/ editing, get it by id and fill out the form
  async function prepareProductUpdate(id) {

    try {
        // Get product by id
        const product = await getDataAsync(`${BASE_URL}product/${id}`);
        // Fill out the form
        document.getElementById('productId').value = product.ProductId; // uses a hidden field - see the form
        document.getElementById('brandId').value = product.BrandId;
        document.getElementById('productName').value = product.ProductName;
        document.getElementById('productDescription').value = product.ProductDescription;
        document.getElementById('productStock').value = product.ProductStock;
        document.getElementById('productPrice').value = product.ProductPrice;
    } // catch and log any errors
    catch (err) {
    console.log(err);
    }
  }

  // Called when form submit button is clicked
  async function addOrUpdateProduct() {
  
    // url
    let url = `${BASE_URL}product`
  
    // Get form fields
    const pId = Number(document.getElementById('productId').value);
    const catId = document.getElementById('brandId').value;
    const pName = document.getElementById('productName').value;
    const pDesc = document.getElementById('productDescription').value;
    const pStock = document.getElementById('productStock').value;
    const pPrice = document.getElementById('productPrice').value;

    // build request body
    const reqBody = JSON.stringify({
    brandId: braId,
    productName: pName,
    productDescription: pDesc,
    productStock: pStock,
    productPrice: pPrice
    });

    // Try catch 
    try {
        let json = "";
        // update includes product id
        if (pId > 0) {
            url+= `/${pId}`;
            json = await postOrPutDataAsync(url, reqBody, 'PUT');
        }
        else {  
            json = await postOrPutDataAsync(url, reqBody, 'POST');
        }
      // Load products
      loadProducts();
      // catch and log any errors
    } catch (err) {
      console.log(err);
      return err;
    }
  }

  // Delete product by id using an HTTP DELETE request
  async function deleteProduct(id) {
        
    if (confirm("Are you sure?")) {
        // url
        const url = `${BASE_URL}product/${id}`;
        
        // Try catch 
        try {
            const json = await deleteDataAsync(url);
            console.log("response: " + json);

            loadProducts();

        // catch and log any errors
        } catch (err) {
            console.log(err);
            return err;
        }
    }
  }

 // Show product button
 function showAddProductButton() {

  let addProductButton= document.getElementById('AddProductButton');

  if (userLoggedIn() === true && sessionStorage.getItem('role') === ('admin')) {
    addProductButton.style.display = 'block';
  }
  else {
    addProductButton.style.display = 'none';
  }
 }

// show login or logout
showLoginLink();

// Load products
loadProducts();
showAddProductButton();