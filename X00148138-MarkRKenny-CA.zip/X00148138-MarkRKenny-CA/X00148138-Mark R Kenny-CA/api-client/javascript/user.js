// Function to display login link if no user logged in
function showLoginLink() {
    const link = document.getElementById('loginLink')
  
    // Read session storage value (set during login) and set link
    if (userLoggedIn() === true) {
      link.innerHTML = 'Logout';
      link.removeAttribute('data-toggle');
      link.removeAttribute('data-target');
      link.addEventListener("click", logout);
    }
    else {
      link.innerHTML = 'Login';
      link.setAttribute('data-toggle', 'modal');
      link.setAttribute('data-target', '#LoginDialog');

    }
  
  }
  
  // Login a user
  async function login() {
  
    // Login url
    const url = `${BASE_URL}login/auth` //api endpoint for login
  
    // Get form fields
    const email = document.getElementById('email').value;
    const pwd = document.getElementById('password').value; //read values
    // build request body
    const reqBody = JSON.stringify({
      username: email,
      password: pwd
    });
  
    // Try catch 
    try {
      const json = await postOrPutDataAsync(url, reqBody, 'POST');
      console.log("response: " + json.user);
  
      // A successful login will return a user
      //set the role for each person 
      if (json.user === false || json.user === undefined) {
        alert("Invalid Username/Password. Try again")}
        else{
        sessionStorage.loggedIn = true;
        sessionStorage.setItem('role',json.role);
        console.log(sessionStore.getItem('role'));

        location.reload(true);
      }
  
      // catch and log any errors
    } catch (err) {
      console.log(err);
      return err;
    }
  
  }
  
  async function logout() {
  
    // logout url
    const url = `${BASE_URL}login/logout`
    // Try catch 
    try {
  
      // send request and via fetch
      const json = await getDataAsync(url);
      console.log("response: " + JSON.stringify(json));

      sessionStorage.loggedIn = false;
      sessionStore.remove('role');
      location.reload(true);

      // catch and log any errors
      }catch (err) {
        console.log(err);
        return err;
      }
  }

  function userLoggedIn() {

    if (sessionStorage.loggedIn == 'true' ) {
      return true;
    }
    else {
      return false;
    }
  }