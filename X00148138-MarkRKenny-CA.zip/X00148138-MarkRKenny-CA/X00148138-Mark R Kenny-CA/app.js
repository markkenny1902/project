// require imports packages required by the application
const express = require('express');
const cors = require('cors')
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser')

const HOST = '0.0.0.0';
const PORT = 8080;

require('./security/passportConfig');

let app = express();

app.use(express.static('api-client'))

// Application settings
app.use((req, res, next) => {
    res.setHeader("Content-Type", "application/json");
    next();
}); 

// Cookie support
app.use(cookieParser());

app.use(bodyParser.text());
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true })); 


app.use(cors({ credentials: true, origin: true }));
app.options('*', cors()) 

/* Configure app Routes to handle requests from browser */
// The home page 
app.use('/', require('./routes/index'));

// route to /brand
app.use('/brand', require('./routes/brand'));

// route to /product
app.use('/product', require('./routes/product'));

// route to /user
app.use('/user', require('./routes/user'));

// route to /login
app.use('/login', require('./routes/login'));

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found: '+ req.method + ":" + req.originalUrl);
    err.status = 404;
    next(err);
});


// Listen for incoming connections
var server = app.listen(PORT, HOST, function() {
    console.log(`Express server listening on http://${HOST}:${PORT}`);
});

// Export this as a module
module.exports = app;