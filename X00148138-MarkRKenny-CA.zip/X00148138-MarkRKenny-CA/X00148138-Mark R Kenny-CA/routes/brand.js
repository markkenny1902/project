const router = require('express').Router();
const validator = require('validator');

// require the database connection
const { sql, dbConnPoolPromise } = require('../database/db.js');
// Define SQL statements here for use in function below
const SQL_SELECT_ALL = 'SELECT * FROM X00148138.Brand ORDER BY BrandName ASC for json path;';
const SQL_SELECT_BY_ID = 'SELECT * FROM X00148138.Brand WHERE BrandId = @id for json path, without_array_wrapper;';


// GET the listings of all categories

router.get('/', async (req, res) => {

    // Get a DB connection and execute SQL
    try {
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // execute query
            .query(SQL_SELECT_ALL);
        
        // Send HTTP response.
        // JSON data from MS SQL is contained in first element of the recordset.
        res.json(result.recordset[0]);

      // Catch and send errors  
      } catch (err) {
        res.status(500)
        res.send(err.message)
      }
});

// GET a single product by id

router.get('/:id', async (req, res) => {

    // read value of id parameter from the request url
    const brandId = req.params.id;

    // If validation fails return an error message
    if (!validator.isNumeric(brandId, { no_symbols: true })) {
        res.json({ "error": "invalid id parameter" });
        return false;
    }

    // If validation passed execute query and return results
    // returns a single product with matching id
    try {
        // Get a DB connection and execute SQL
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // set name parameter(s) in query
            .input('id', sql.Int, brandId)
            // execute query
            .query(SQL_SELECT_BY_ID);

        // Send response with JSON result    
        res.json(result.recordset)

        } catch (err) {
            res.status(500)
            res.send(err.message)
        }
});

module.exports = router;
